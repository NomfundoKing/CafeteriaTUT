package za.ac.tut.controllers;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.entity.Customer;
import za.ac.tut.entity.CustomerFacadeLocal;

public class CustomerRegistrationServlet extends HttpServlet {

    @EJB
    private CustomerFacadeLocal cfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        
        if (password == null || password.trim().isEmpty()) {
            request.setAttribute("errorMessage", "Password cannot be empty. Please provide a valid password.");
            RequestDispatcher rd = request.getRequestDispatcher("customer_registration.jsp");
            rd.forward(request, response);
            return;
        }

        
        Customer existingCustomer = cfl.findByUsername(username);

        if (existingCustomer != null) {
            request.setAttribute("errorMessage", "Username already exists. Please choose another one.");
            RequestDispatcher rd = request.getRequestDispatcher("customer_registration.jsp");
            rd.forward(request, response);
        } else {
            
            Customer newCustomer = new Customer(username, password);
            cfl.create(newCustomer);


            request.setAttribute("successMessage", "Registration successful. Please log in.");
            RequestDispatcher rd = request.getRequestDispatcher("customer_login.jsp");
            rd.forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Handles customer registration logic.";
    }
}
