/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.entity;

import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author boitu
 */
@Local
public interface OrderAdminFacadeLocal {

    void create(OrderAdmin orderAdmin);

    void edit(OrderAdmin orderAdmin);

    void remove(OrderAdmin orderAdmin);

    OrderAdmin find(Object id);

    List<OrderAdmin> findAll();

    List<OrderAdmin> findRange(int[] range);

    int count();
    
    OrderAdmin findByUsername(String username);
}
