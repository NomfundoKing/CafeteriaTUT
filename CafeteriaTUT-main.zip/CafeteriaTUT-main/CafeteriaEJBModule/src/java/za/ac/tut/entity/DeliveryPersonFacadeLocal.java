/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.entity;

import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author boitu
 */
@Local
public interface DeliveryPersonFacadeLocal {

    void create(DeliveryPerson deliveryPerson);

    void edit(DeliveryPerson deliveryPerson);

    void remove(DeliveryPerson deliveryPerson);

    DeliveryPerson find(Object id);

    List<DeliveryPerson> findAll();

    List<DeliveryPerson> findRange(int[] range);

    int count();
    
    DeliveryPerson findByUsername(String username);
}
