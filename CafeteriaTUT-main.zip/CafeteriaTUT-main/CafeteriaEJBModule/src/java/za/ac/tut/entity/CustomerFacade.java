/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.entity;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author boitu
 */
@Stateless
public class CustomerFacade extends AbstractFacade<Customer> implements CustomerFacadeLocal {

    @PersistenceContext(unitName = "CafeteriaEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CustomerFacade() {
        super(Customer.class);
    }

    @Override
    public Customer findByUsername(String username) {
    try{
        Query query = em.createQuery("SELECT s FROM Customer s WHERE s.username = :username");
        query.setParameter("username", username);
         
        Customer customer =(Customer) query.getSingleResult();
        return customer;
    } catch (javax.persistence.NoResultException e) {
        return null; 
    }
    }
    
}
