/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.entity;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author boitu
 */
@Stateless
public class DeliveryPersonFacade extends AbstractFacade<DeliveryPerson> implements DeliveryPersonFacadeLocal {

    @PersistenceContext(unitName = "CafeteriaEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public DeliveryPersonFacade() {
        super(DeliveryPerson.class);
    }
   
    @Override
    public DeliveryPerson findByUsername(String username) {
        try{
        Query query = em.createQuery("SELECT s FROM DeliveryPerson s WHERE s.username = :username");
        query.setParameter("username", username);
        DeliveryPerson deliveryPerson = (DeliveryPerson) query.getSingleResult();
        return deliveryPerson;
    } catch (javax.persistence.NoResultException e) {
        return null; 
    }
    }
        
    
    
}
