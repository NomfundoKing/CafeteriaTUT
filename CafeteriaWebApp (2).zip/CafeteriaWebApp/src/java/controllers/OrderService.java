/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USER
 */
public class OrderService {

    public List<Order> getOrders() {
        List<Order> orders = new ArrayList<>();
        // Add some sample orders
        orders.add(new Order(101, "Pending", "1x Burger, 1x Fries"));
        orders.add(new Order(102, "Done", "2x Pizza, 1x Coke"));
        orders.add(new Order(103, "Pending", "1x Pasta, 1x Juice"));
        orders.add(new Order(104, "Done", "3x Sandwiches"));

        return orders;
    }
}
