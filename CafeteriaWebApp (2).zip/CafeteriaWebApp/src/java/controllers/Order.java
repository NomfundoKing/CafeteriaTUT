package controllers;

public class Order {
    private int orderNumber;
    private String status;
    private String description;

    public Order(int orderNumber, String status, String description) {
        this.orderNumber = orderNumber;
        this.status = status;
        this.description = description;
    }

    // Getters
    public int getOrderNumber() {
        return orderNumber;
    }

    public String getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }

    // Setters if needed
    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
