package controllers;

public class Order {
    private int orderNumber;
    private String status;
    private String description;
    private String location;

    public Order(int orderNumber, String status, String description, String location) {
        this.orderNumber = orderNumber;
        this.status = status;
        this.description = description;
        this.location = location;
    }

    public int getOrderNumber() {
        return orderNumber;
    }

    public String getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }

    public String getLocation() {
        return location;
    }
}
