package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class GetOrderServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle GET request (display orders for chef)
        HttpSession session = request.getSession();
        List<Order> orders = (List<Order>) session.getAttribute("orders");

        if (orders != null) {
            request.setAttribute("orders", orders);
            request.getRequestDispatcher("orderList.jsp").forward(request, response);
        } else {
            response.getWriter().println("No orders found.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Handle POST request (submit new order)
        HttpSession session = request.getSession();
        List<Order> orders = (List<Order>) session.getAttribute("orders");
        
        if (orders == null) {
            orders = new ArrayList<>();
        }

        String[] selectedItems = request.getParameterValues("item");
        String location = request.getParameter("location");

        if (selectedItems != null && location != null && !location.isEmpty()) {
            StringBuilder description = new StringBuilder();
            for (String item : selectedItems) {
                description.append(item).append(", ");
            }
            String desc = description.toString().replaceAll(", $", "");

            int orderNumber = orders.size() + 1;
            Order order = new Order(orderNumber, "Pending", desc, location);
            orders.add(order);
            session.setAttribute("orders", orders);
        }

        response.sendRedirect("confirmation.html");
    }
}