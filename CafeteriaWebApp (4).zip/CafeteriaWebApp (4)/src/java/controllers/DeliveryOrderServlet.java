/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author USER
 */
public class DeliveryOrderServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
            // Get orders from the session (not using OrderService anymore)
        HttpSession session = request.getSession();
        List<Order> orders = (List<Order>) session.getAttribute("orders");

        if (orders != null) {
            request.setAttribute("orders", orders);
            RequestDispatcher dispatcher = request.getRequestDispatcher("list_and_loc.jsp");
            dispatcher.forward(request, response);
        } else {
            // If no orders are in the session, you can redirect or show an error
            response.getWriter().println("No orders found in session.");
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    HttpSession session = request.getSession(false); 

    
        List<Order> orders = (List<Order>) session.getAttribute("orders");
        if (orders != null && !orders.isEmpty()) {
            request.setAttribute("orders", orders);
            request.getRequestDispatcher("list_and_loc.jsp").forward(request, response);
            return;
        }
    }

   
}

    

   
    


